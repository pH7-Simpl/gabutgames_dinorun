#include "Screen.h"

void Engine::Screen::SetGame(Game* engine)
{
	this->game = engine;
}
